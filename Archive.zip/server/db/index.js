const db = require('./db');

require('./models');

module.exports = db;
