#TTP FS Assessment - IEX API Stock Portfolio Web App

1. npm install
2. localhost/PORT is set to 5500
3. Sometimes a refresh is needed when going from Transactions to Portfolio, still checking why
